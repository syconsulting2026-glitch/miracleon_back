import {
  DataTypes,
  Model,
  InferAttributes,
  InferCreationAttributes,
  CreationOptional,
} from "sequelize";
import { sequelize } from "../db/sequelize";

export class User extends Model<InferAttributes<User>, InferCreationAttributes<User>> {
  declare id: CreationOptional<number>;
  declare email: string;
  declare passwordHash: string;
  declare name: string | null;

  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

User.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "사용자 PK",
    },
    email: {
      type: DataTypes.STRING(191),
      allowNull: false,
      unique: true,
      comment: "로그인 이메일(유니크)",
    },
    passwordHash: {
      type: DataTypes.STRING(255),
      allowNull: false,
      comment: "비밀번호 해시(bcrypt 등)",
    },
    name: {
      type: DataTypes.STRING(60),
      allowNull: true,
      comment: "표시 이름(닉네임)",
    },
    createdAt: {
      type: DataTypes.DATE,
      comment: "생성일시",
    },
    updatedAt: {
      type: DataTypes.DATE,
      comment: "수정일시",
    },
  },
  {
    sequelize,
    tableName: "users",
    underscored: true,
    comment: "회원 정보",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
