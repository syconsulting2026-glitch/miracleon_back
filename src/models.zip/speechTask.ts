import {
  DataTypes,
  Model,
  InferAttributes,
  InferCreationAttributes,
  CreationOptional,
} from "sequelize";
import { sequelize } from "../db/sequelize";

export class SpeechTask extends Model<InferAttributes<SpeechTask>, InferCreationAttributes<SpeechTask>> {
  declare id: CreationOptional<number>;
  declare title: string;
  declare prompt: string;
  declare script: string | null;
  declare level: number;
  declare tags: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

SpeechTask.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "스피치 과제 PK",
    },
    title: {
      type: DataTypes.STRING(120),
      allowNull: false,
      comment: "스피치 과제 제목",
    },
    prompt: {
      type: DataTypes.TEXT,
      allowNull: false,
      comment: "스피치 주제/지시문",
    },
    script: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: "예시 스크립트(선택)",
    },
    level: {
      type: DataTypes.TINYINT.UNSIGNED,
      allowNull: false,
      defaultValue: 1,
      comment: "난이도(예: 1~5)",
    },
    tags: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: "태그 CSV(예: daily,interview)",
    },
    createdAt: { type: DataTypes.DATE, comment: "생성일시", field: "created_at" },
    updatedAt: { type: DataTypes.DATE, comment: "수정일시", field: "updated_at" },
  },
  {
    sequelize,
    tableName: "speech_tasks",
    underscored: true,
    comment: "스피치 과제(주제/스크립트)",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
