import {
  DataTypes,
  Model,
  InferAttributes,
  InferCreationAttributes,
  CreationOptional,
} from "sequelize";
import { sequelize } from "../db/sequelize";

export class VocabItem extends Model<InferAttributes<VocabItem>, InferCreationAttributes<VocabItem>> {
  declare id: CreationOptional<number>;
  declare word: string;
  declare meaning: string;
  declare example: string | null;
  declare level: number;
  declare tags: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

VocabItem.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "단어 PK",
    },
    word: {
      type: DataTypes.STRING(120),
      allowNull: false,
      comment: "영단어",
    },
    meaning: {
      type: DataTypes.STRING(255),
      allowNull: false,
      comment: "뜻(한글/영문 가능)",
    },
    example: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: "예문(선택)",
    },
    level: {
      type: DataTypes.TINYINT.UNSIGNED,
      allowNull: false,
      defaultValue: 1,
      comment: "난이도(예: 1~5)",
    },
    tags: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: "태그 CSV(예: travel,business)",
    },
    createdAt: { type: DataTypes.DATE, comment: "생성일시", field: "created_at" },
    updatedAt: { type: DataTypes.DATE, comment: "수정일시", field: "updated_at" },
  },
  {
    sequelize,
    tableName: "vocab_items",
    underscored: true,
    comment: "영어 단어 콘텐츠",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
