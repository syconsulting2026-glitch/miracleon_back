import { User } from "./users";
import { VocabItem } from "./vocabtem";
import { SentenceItem } from "./sentenceItem";
import { SpeechTask } from "./speechTask";
import { StudyLog } from "./studyLog";
import { ReviewQueue } from "./reviewQueue";
import { SpeechRecord } from "./speechRecord";

// 관계(Association)
User.hasMany(StudyLog, { foreignKey: "userId" });
StudyLog.belongsTo(User, { foreignKey: "userId" });

User.hasMany(ReviewQueue, { foreignKey: "userId" });
ReviewQueue.belongsTo(User, { foreignKey: "userId" });

User.hasMany(SpeechRecord, { foreignKey: "userId" });
SpeechRecord.belongsTo(User, { foreignKey: "userId" });

SpeechTask.hasMany(SpeechRecord, { foreignKey: "speechTaskId" });
SpeechRecord.belongsTo(SpeechTask, { foreignKey: "speechTaskId" });

export {
  User,
  VocabItem,
  SentenceItem,
  SpeechTask,
  StudyLog,
  ReviewQueue,
  SpeechRecord,
};
