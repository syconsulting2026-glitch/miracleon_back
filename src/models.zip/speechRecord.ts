import {
  DataTypes,
  Model,
  InferAttributes,
  InferCreationAttributes,
  CreationOptional,
} from "sequelize";
import { sequelize } from "../db/sequelize";

export class SpeechRecord extends Model<
  InferAttributes<SpeechRecord>,
  InferCreationAttributes<SpeechRecord>
> {
  declare id: CreationOptional<number>;
  declare userId: number;
  declare speechTaskId: number;
  declare audioUrl: string;
  declare transcript: string | null;
  declare score: number | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

SpeechRecord.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "스피치 제출 PK",
    },
    userId: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      field: "user_id",
      comment: "사용자 ID(FK)",
      references: { model: "users", key: "id" },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
    speechTaskId: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      field: "speech_task_id",
      comment: "스피치 과제 ID(FK)",
      references: { model: "speech_tasks", key: "id" },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
    audioUrl: {
      type: DataTypes.STRING(512),
      allowNull: false,
      field: "audio_url",
      comment: "녹음 파일 경로/URL(S3 등)",
    },
    transcript: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: "STT 변환 텍스트(2차 확장)",
    },
    score: {
      type: DataTypes.FLOAT,
      allowNull: true,
      comment: "평가 점수(2차 확장)",
    },
    createdAt: { type: DataTypes.DATE, comment: "생성일시", field: "created_at" },
    updatedAt: { type: DataTypes.DATE, comment: "수정일시", field: "updated_at" },
  },
  {
    sequelize,
    tableName: "speech_records",
    underscored: true,
    comment: "사용자 스피치 제출(녹음/점수/전사)",
    indexes: [
      { name: "idx_speech_records_user", fields: ["user_id"] },
      { name: "idx_speech_records_task", fields: ["speech_task_id"] },
      { name: "idx_speech_records_created_at", fields: ["created_at"] },
    ],
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
