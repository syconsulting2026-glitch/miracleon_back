import { DataTypes, Model, InferAttributes, InferCreationAttributes, CreationOptional } from "sequelize";
import { sequelize } from "../db/sequelize";

export type ReviewContentType = "VOCAB" | "SENTENCE" | "SPEECH";

export class ReviewQueue extends Model<InferAttributes<ReviewQueue>, InferCreationAttributes<ReviewQueue>> {
  declare id: CreationOptional<number>;
  declare userId: number;
  declare contentType: ReviewContentType;
  declare contentId: number;
  declare nextReviewAt: Date;
  declare intervalDays: number;
  declare easeFactor: number;
  declare wrongCount: number;

  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

ReviewQueue.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "복습 큐 PK",
    },
    userId: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      comment: "사용자 ID(FK)",
    },
    contentType: {
      type: DataTypes.ENUM("VOCAB", "SENTENCE", "SPEECH"),
      allowNull: false,
      comment: "콘텐츠 타입",
    },
    contentId: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      comment: "콘텐츠 ID",
    },
    nextReviewAt: {
      type: DataTypes.DATE,
      allowNull: false,
      comment: "다음 복습 일시",
    },
    intervalDays: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 1,
      comment: "복습 간격(일)",
    },
    easeFactor: {
      type: DataTypes.FLOAT,
      allowNull: false,
      defaultValue: 2.5,
      comment: "난이도 계수(복습 알고리즘)",
    },
    wrongCount: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
      comment: "누적 오답 횟수",
    },
    createdAt: { type: DataTypes.DATE, comment: "생성일시" },
    updatedAt: { type: DataTypes.DATE, comment: "수정일시" },
  },
  {
    sequelize,
    tableName: "review_queue",
    underscored: true,
    comment: "사용자별 복습 대상 및 스케줄 관리",
    indexes: [
      { unique: true, fields: ["user_id", "content_type", "content_id"] },
      { fields: ["user_id", "next_review_at"] },
    ],
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
