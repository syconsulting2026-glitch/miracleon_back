import {
  DataTypes,
  Model,
  InferAttributes,
  InferCreationAttributes,
  CreationOptional,
} from "sequelize";
import { sequelize } from "../db/sequelize";

export type StudyContentType = "VOCAB" | "SENTENCE" | "SPEECH";

export class StudyLog extends Model<InferAttributes<StudyLog>, InferCreationAttributes<StudyLog>> {
  declare id: CreationOptional<number>;
  declare userId: number;
  declare contentType: StudyContentType;
  declare contentId: number;
  declare isCorrect: boolean;
  declare meta: object | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

StudyLog.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "학습 로그 PK",
    },
    userId: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      field: "user_id",
      comment: "사용자 ID(FK)",
      references: { model: "users", key: "id" },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
    contentType: {
      type: DataTypes.ENUM("VOCAB", "SENTENCE", "SPEECH"),
      allowNull: false,
      field: "content_type",
      comment: "학습 콘텐츠 타입",
    },
    contentId: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      field: "content_id",
      comment: "콘텐츠 ID(각 테이블의 id)",
    },
    isCorrect: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      field: "is_correct",
      comment: "정답 여부",
    },
    meta: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: "추가 메타데이터(선택: 사용자 답안, 소요시간 등)",
    },
    createdAt: { type: DataTypes.DATE, comment: "생성일시", field: "created_at" },
    updatedAt: { type: DataTypes.DATE, comment: "수정일시", field: "updated_at" },
  },
  {
    sequelize,
    tableName: "study_logs",
    underscored: true,
    comment: "사용자 학습 기록(정답/오답/메타)",
    indexes: [
      { name: "idx_study_logs_user", fields: ["user_id"] },
      { name: "idx_study_logs_user_content", fields: ["user_id", "content_type", "content_id"] },
      { name: "idx_study_logs_created_at", fields: ["created_at"] },
    ],
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
