import {
  DataTypes,
  Model,
  InferAttributes,
  InferCreationAttributes,
  CreationOptional,
} from "sequelize";
import { sequelize } from "../db/sequelize";

export class SentenceItem extends Model<
  InferAttributes<SentenceItem>,
  InferCreationAttributes<SentenceItem>
> {
  declare id: CreationOptional<number>;
  declare prompt: string;
  declare answer: string;
  declare explanation: string | null;
  declare level: number;
  declare tags: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
}

SentenceItem.init(
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: "문장 문제 PK",
    },
    prompt: {
      type: DataTypes.TEXT,
      allowNull: false,
      comment: "문제/지시문(문장 만들기용)",
    },
    answer: {
      type: DataTypes.TEXT,
      allowNull: false,
      comment: "정답 문장(정규화된 정답)",
    },
    explanation: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: "해설(선택)",
    },
    level: {
      type: DataTypes.TINYINT.UNSIGNED,
      allowNull: false,
      defaultValue: 1,
      comment: "난이도(예: 1~5)",
    },
    tags: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: "태그 CSV(예: grammar,tense)",
    },
    createdAt: { type: DataTypes.DATE, comment: "생성일시", field: "created_at" },
    updatedAt: { type: DataTypes.DATE, comment: "수정일시", field: "updated_at" },
  },
  {
    sequelize,
    tableName: "sentence_items",
    underscored: true,
    comment: "영어 문장 만들기(문제/정답/해설)",
    charset: "utf8mb4",
    collate: "utf8mb4_unicode_ci",
  }
);
